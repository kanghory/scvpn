import logging
import subprocess
import requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, CallbackContext, ConversationHandler, MessageHandler, Filters, CallbackQueryHandler

# Konfigurasi logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# Load admin IDs from file
def load_admin_ids(file_path):
    try:
        with open(file_path, 'r') as file:
            admin_ids = [int(line.strip()) for line in file if line.strip().isdigit()]
        return admin_ids
    except Exception as e:
        logger.error(f"Error loading admin IDs: {e}")
        return []

# Daftar ID admin yang diizinkan
ADMIN_IDS = load_admin_ids('andy.txt')

# States for conversation
REGISTER, REGISTER_NAME, REGISTER_EXP, EXTEND, EXTEND_DAYS, DELETE, ADD_ADMIN, REMOVE_ADMIN = range(8)

def count_registered_ips():
    try:
        response = requests.get('https://raw.githubusercontent.com/kanghory/izin/main/ip')
        response.raise_for_status()
        ip_list = response.text.splitlines()
        return len(ip_list)
    except requests.RequestException as e:
        logger.error(f"Error while fetching IP list: {e}")
        return 0

# Fungsi untuk menampilkan menu awal dengan tombol
def start(update: Update, context: CallbackContext) -> int:
    user = update.message.from_user
    user_id = user.id
    username = user.username if user.username else "Tidak ada username"

    total_ips = count_registered_ips()

    keyboard = [
    [InlineKeyboardButton("🆕 Daftarkan IP", callback_data='register')],
    [InlineKeyboardButton("🔄 Perpanjang IP", callback_data='extend')],
    [InlineKeyboardButton("❌ Hapus IP", callback_data='delete')],
    [InlineKeyboardButton("➕ Tambah Admin", callback_data='add_admin')],
    [InlineKeyboardButton("📋 List Admin", callback_data='list_admin')],
    [InlineKeyboardButton("🗑️ Hapus Admin", callback_data='remove_admin')]  # Tombol baru
]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.message.reply_text(
        f"Selamat datang, {username} (ID: {user_id})! 🎉\n\n"
        f"Total IP terdaftar: {total_ips}\n\n"
        "Gunakan tombol di bawah untuk mengelola IP:\n"
        "🔹 Daftarkan IP baru\n"
        "🔹 Perpanjang masa berlaku IP\n"
        "🔹 Hapus IP yang terdaftar\n",
        reply_markup=reply_markup
    )
    return ConversationHandler.END

def button(update: Update, context: CallbackContext) -> int:
    query = update.callback_query
    query.answer()

    if query.data == 'register':
        query.edit_message_text("🔄 Masukkan IP yang ingin didaftarkan:")
        return REGISTER
    elif query.data == 'extend':
        query.edit_message_text("🔄 Masukkan IP yang ingin diperpanjang:")
        return EXTEND
    elif query.data == 'delete':
        query.edit_message_text("❌ Masukkan IP yang ingin dihapus:")
        return DELETE
    elif query.data == 'add_admin':
        query.edit_message_text("➕ Masukkan ID Telegram admin yang ingin ditambahkan:")
        return ADD_ADMIN
    elif query.data == 'list_admin':
        return list_admin(update, context)
    elif query.data == 'remove_admin':
        query.edit_message_text("🗑️ Masukkan ID admin yang ingin dihapus:")
        return REMOVE_ADMIN  # State baru untuk hapus admin

def register_ip(update: Update, context: CallbackContext) -> int:
    user_id = update.message.from_user.id
    if user_id not in ADMIN_IDS:
        update.message.reply_text("🚫 Anda tidak memiliki izin untuk menggunakan perintah ini.")
        return ConversationHandler.END

    context.user_data['ip'] = update.message.text
    update.message.reply_text("✍️ Masukkan Nama:")
    return REGISTER_NAME

def handle_register_name(update: Update, context: CallbackContext) -> int:
    context.user_data['name'] = update.message.text
    update.message.reply_text("📅 Masukkan Masa Berlaku (hari):")
    return REGISTER_EXP

def finalize_register(update: Update, context: CallbackContext) -> int:
    exp = update.message.text
    ip = context.user_data['ip']
    name = context.user_data['name']

    try:
        result = subprocess.run(
            ["/bin/bash", "andyregis.sh", ip, name, exp],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            update.message.reply_text(f"✅ IP berhasil didaftarkan!\nOutput:\n{result.stdout}")
        else:
            update.message.reply_text(f"❌ Error:\n{result.stderr}")
    except Exception as e:
        logger.error(f"Error while registering IP: {e}")
        update.message.reply_text(f"🚨 Terjadi kesalahan: {e}")

    return ConversationHandler.END

def handle_extend_ip(update: Update, context: CallbackContext) -> int:
    context.user_data['ip'] = update.message.text
    update.message.reply_text("📅 Masukkan Tambahan Hari:")
    return EXTEND_DAYS

def finalize_extend(update: Update, context: CallbackContext) -> int:
    extra_days = update.message.text
    ip = context.user_data['ip']

    try:
        result = subprocess.run(
            ["/bin/bash", "andyextend.sh", ip, extra_days],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            update.message.reply_text(f"✅ Masa berlaku IP berhasil diperpanjang!\nOutput:\n{result.stdout}")
        else:
            update.message.reply_text(f"❌ Error:\n{result.stderr}")
    except Exception as e:
        logger.error(f"Error while extending IP: {e}")
        update.message.reply_text(f"🚨 Terjadi kesalahan: {e}")

    return ConversationHandler.END

def handle_delete_ip(update: Update, context: CallbackContext) -> int:
    ip = update.message.text

    try:
        result = subprocess.run(
            ["/bin/bash", "andydelete.sh", ip],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            update.message.reply_text(f"✅ IP berhasil dihapus!\nOutput:\n{result.stdout}")
        else:
            update.message.reply_text(f"❌ Error:\n{result.stderr}")
    except Exception as e:
        logger.error(f"Error while deleting IP: {e}")
        update.message.reply_text(f"🚨 Terjadi kesalahan: {e}")

    return ConversationHandler.END
    
def add_admin(update: Update, context: CallbackContext) -> int:
    user_id = update.message.from_user.id
    if user_id not in ADMIN_IDS:
        update.message.reply_text("🚫 Anda tidak memiliki izin untuk menambah admin.")
        return ConversationHandler.END

    new_admin_id = update.message.text.strip()
    if not new_admin_id.isdigit():
        update.message.reply_text("⚠️ ID Telegram harus berupa angka. Coba lagi.")
        return ADD_ADMIN

    # Simpan ke andy.txt
    try:
        with open('andy.txt', 'a') as file:
            file.write(new_admin_id + '\n')

        update.message.reply_text(f"✅ Admin dengan ID {new_admin_id} berhasil ditambahkan!")
    except Exception as e:
        logger.error(f"Error menambah admin: {e}")
        update.message.reply_text(f"🚨 Terjadi kesalahan: {e}")

    return ConversationHandler.END
    
def list_admin(update: Update, context: CallbackContext) -> int:
    try:
        with open('andy.txt', 'r') as file:
            admin_list = [line.strip() for line in file if line.strip().isdigit()]
        
        if not admin_list:
            update.callback_query.edit_message_text("⚠️ Tidak ada admin yang terdaftar.")
        else:
            admin_text = "\n".join([f"🔹 {admin_id}" for admin_id in admin_list])
            update.callback_query.edit_message_text(f"📋 **Daftar Admin Terdaftar:**\n{admin_text}", parse_mode="Markdown")
    except Exception as e:
        logger.error(f"Error membaca daftar admin: {e}")
        update.callback_query.edit_message_text("🚨 Gagal mengambil daftar admin.")

    return ConversationHandler.END            
    
def remove_admin(update: Update, context: CallbackContext) -> int:
    user_id = update.message.from_user.id
    if user_id not in ADMIN_IDS:
        update.message.reply_text("🚫 Anda tidak memiliki izin untuk menghapus admin.")
        return ConversationHandler.END

    admin_to_remove = update.message.text.strip()

    try:
        with open('andy.txt', 'r') as file:
            admin_list = [line.strip() for line in file if line.strip().isdigit()]

        if admin_to_remove not in admin_list:
            update.message.reply_text("⚠️ ID admin tidak ditemukan.")
            return ConversationHandler.END

        admin_list.remove(admin_to_remove)

        with open('andy.txt', 'w') as file:
            file.write("\n".join(admin_list) + "\n")

        update.message.reply_text(f"✅ Admin dengan ID {admin_to_remove} berhasil dihapus!")
    except Exception as e:
        logger.error(f"Error menghapus admin: {e}")
        update.message.reply_text("🚨 Terjadi kesalahan saat menghapus admin.")

    return ConversationHandler.END    

def main() -> None:
    TOKEN = "7782629701:AAGZoAor9Ng6S2qxtoPWxzrxwbFNr2u4RVY"

    updater = Updater(TOKEN)
    dispatcher = updater.dispatcher

    conversation_handler = ConversationHandler(
    entry_points=[CallbackQueryHandler(button)],
    states={
        REGISTER: [MessageHandler(Filters.text & ~Filters.command, register_ip)],
        REGISTER_NAME: [MessageHandler(Filters.text & ~Filters.command, handle_register_name)],
        REGISTER_EXP: [MessageHandler(Filters.text & ~Filters.command, finalize_register)],
        EXTEND: [MessageHandler(Filters.text & ~Filters.command, handle_extend_ip)],
        EXTEND_DAYS: [MessageHandler(Filters.text & ~Filters.command, finalize_extend)],
        DELETE: [MessageHandler(Filters.text & ~Filters.command, handle_delete_ip)],
        ADD_ADMIN: [MessageHandler(Filters.text & ~Filters.command, add_admin)],
        REMOVE_ADMIN: [MessageHandler(Filters.text & ~Filters.command, remove_admin)],  # Tambahkan handler untuk hapus admin
    },
    fallbacks=[]
)

    dispatcher.add_handler(CommandHandler("start", start))
    dispatcher.add_handler(conversation_handler)

    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
